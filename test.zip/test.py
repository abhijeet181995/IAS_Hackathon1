import sensor
import time
while True:
    print(sensor.sensor_object[2].get()) #
    time.sleep(3)